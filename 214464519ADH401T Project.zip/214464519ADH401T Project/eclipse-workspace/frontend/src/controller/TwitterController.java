package controller;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import model.Twitter;
import service.TwitterEJB;

@ManagedBean(name="twittercontroller")
@SessionScoped

public class TwitterController {
	  @EJB
	  TwitterEJB Twitterservice;
	   
	@ManagedProperty(value="#{twitter}")
	private Twitter twitter;
	
	
	/*on your TwitterController add this method to send tweet*/
	public void sendDirectMessage()
	{
		Twitterservice.saveNew(twitter.getEntity());
	}

	public Twitter getTwitter() {
		return twitter;
	}

	public void setTwitter(Twitter twitter) {
		this.twitter = twitter;
	}
	
	

}
