package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="tbl_twitter")
public class TwitterEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO) 
	private Long id;
	
	private String message;
	public String receipientName;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getMesssage() {
		return message;
	}
	public void setMesssage(String message) {
		this.message = message;
	}

	public String getReceipientName() {
		return getReceipientName();
	}
	public void setReceipientName(String receipientName) {
		this.receipientName=receipientName;
	}
	

}
