package model;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name="twitter")
@SessionScoped
public class Twitter {
	private String message;
	private String receipientName;
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getReceipientName() {
		return receipientName;
	}

	public void setReceipientName(String receipientName) {
		this.receipientName = receipientName;
	}

	
	//put this method under Twitter.java model
	public TwitterEntity getEntity()
	{
	TwitterEntity twitterentity= new TwitterEntity();
	twitterentity.setMesssage(message);
	twitterentity.setReceipientName(receipientName);
	return twitterentity;
	}
}
